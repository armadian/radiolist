import pandas as pd
import numpy as np
import os
import joblib
import time
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier

CSV_PATH = "attrition_dataset_30000.csv"
MODEL_PATH = "xgb_model.pkl"

def main():
    print("=== ENTRAÎNEMENT DU MODÈLE : XGBOOST (SUR DONNÉES RÉALISTES) ===")
    
    if not os.path.exists(CSV_PATH):
        raise FileNotFoundError(f"Fichier de données '{CSV_PATH}' non trouvé.")
        
    df = pd.read_csv(CSV_PATH)
    

    X = df.drop(columns=['Client_ID', 'Attrition_Target'])
    y = df['Attrition_Target']
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print("\nEntraînement de XGBoost Classifier...")
    start_train = time.time()
    
    xgb_model = XGBClassifier(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        random_state=42,
        eval_metric='logloss',
        n_jobs=-1
    )
    xgb_model.fit(X_train, y_train)
    
    print(f"Modèle entraîné en {time.time() - start_train:.2f} secondes.")
    

    joblib.dump(xgb_model, MODEL_PATH)
    print(f"Modèle sauvegardé dans : '{MODEL_PATH}'")

if __name__ == "__main__":
    main()
