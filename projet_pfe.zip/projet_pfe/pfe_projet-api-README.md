# API FastAPI - Prédiction d'Attrition Client (XGBoost)

Cette API sert le modèle XGBoost optimisé pour prédire le risque d'attrition client (churn) d'une banque.

## 🚀 Installation & Lancement

1. **Installer les dépendances**
```bash
pip install -r requirements.txt
```

2. **Lancer le serveur API**
```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```
Le serveur sera disponible sur `http://localhost:8000`.

## 📌 Endpoints Principaux

- **Documentation Swagger UI** : `http://localhost:8000/docs` (Interface web interactive pour tester l'API)
- **Santé de l'API** : `GET /health`
- **Infos du Modèle** : `GET /model/info`
- **Prédiction (1 client)** : `POST /predict`
- **Prédictions en lot** : `POST /predict/batch`

## 🧪 Tester l'API

Un script de test automatique est fourni. Pendant que l'API tourne, ouvrez un nouveau terminal et lancez :
```bash
python test_api.py
```

## 📝 Features requises
L'API attend 17 features exactes pour chaque prédiction, notamment l'âge, l'ancienneté, les revenus, le solde de carte de crédit, la chute des flux créditeurs, l'utilisation de l'application BBM, etc.
Le détail est consultable via `GET /features` ou dans la documentation `/docs`.
