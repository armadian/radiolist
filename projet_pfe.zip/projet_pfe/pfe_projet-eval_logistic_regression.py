import pandas as pd
import numpy as np
import os
import joblib
import time
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report
)

CSV_PATH = "attrition_dataset_30000.csv"
MODEL_PATH = "lr_model.pkl"

def main():
    print("=== ÉVALUATION DU MODÈLE : RÉGRESSION LOGISTIQUE (SUR DONNÉES RÉALISTES) ===")
    
    if not os.path.exists(MODEL_PATH):
        print(f"Erreur : '{MODEL_PATH}' n'existe pas. Veuillez lancer train_logistic_regression.py.")
        return

    # 1. Chargement des données de test
    df = pd.read_csv(CSV_PATH)
    X = df.drop(columns=['Client_ID', 'Attrition_Target'])
    y = df['Attrition_Target']
    
    _, X_test, _, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # 2. Chargement du modèle
    lr_pipeline = joblib.load(MODEL_PATH)
    
    # 3. Prédictions
    y_pred = lr_pipeline.predict(X_test)
    y_pred_proba = lr_pipeline.predict_proba(X_test)[:, 1]
    
    # 4. Métriques
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_pred_proba)
    
    # 5. Affichage
    print("\n" + "="*50)
    print(" RÉSULTATS DE L'ÉVALUATION (RÉGRESSION LOGISTIQUE)")
    print("="*50)
    print(f"1. Accuracy  : {accuracy:.4%}")
    print(f"2. Precision : {precision:.4%}")
    print(f"3. Recall    (Sensibilité) : {recall:.4%}")
    print(f"4. F1-Score  : {f1:.4%}")
    print(f"5. ROC-AUC   : {roc_auc:.4f}")
    print("="*50)
    
    print("\nMatrice de confusion :")
    cm = confusion_matrix(y_test, y_pred)
    print(f"  [Vrais Actifs  : {cm[0,0]:<5}]  [Faux Churns : {cm[0,1]:<5}]")
    print(f"  [Faux Actifs  : {cm[1,0]:<5}]  [Vrais Churns : {cm[1,1]:<5}]")

if __name__ == "__main__":
    main()
