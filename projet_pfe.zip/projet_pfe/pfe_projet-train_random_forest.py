import pandas as pd
import numpy as np
import os
import joblib
import time
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Configuration
CSV_PATH = "attrition_dataset_30000.csv"
MODEL_PATH = "rf_model.pkl"

def main():
    print("=== ENTRAÎNEMENT DU MODÈLE : RANDOM FOREST (SUR DONNÉES RÉALISTES) ===")
    
    if not os.path.exists(CSV_PATH):
        raise FileNotFoundError(f"Fichier de données '{CSV_PATH}' non trouvé.")
        
    # 1. Chargement des données
    start_time = time.time()
    df = pd.read_csv(CSV_PATH)
    print(f"Données chargées en {time.time() - start_time:.2f} secondes. Shape : {df.shape}")
    
    # 2. Préparation des caractéristiques et de la cible
    X = df.drop(columns=['Client_ID', 'Attrition_Target'])
    y = df['Attrition_Target']
    
    # 3. Séparation Train/Test (80% Train, 20% Test)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Échantillon d'entraînement : {X_train.shape[0]} clients")
    print(f"Échantillon de test         : {X_test.shape[0]} clients")
    
    # 4. Entraînement de Random Forest
    print("\nEntraînement de RandomForestClassifier...")
    start_train = time.time()
    
    # On limite la profondeur et le nombre de feuilles pour avoir un bon modèle généraliste
    rf_model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    
    print(f"Modèle entraîné en {time.time() - start_train:.2f} secondes.")
    
    # 5. Sauvegarde
    joblib.dump(rf_model, MODEL_PATH)
    print(f"Modèle sauvegardé dans : '{MODEL_PATH}'")

if __name__ == "__main__":
    main()
