import pandas as pd
import numpy as np
import os
import joblib
import time
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report
)
from xgboost import XGBClassifier

CSV_PATH = "attrition_dataset_30000.csv"
MODEL_PATH = "optimized_xgb_model.pkl"

def main():
    print("=== PIPELINE D'OPTIMISATION AVANCÉE : XGBOOST (SUR DONNÉES RÉALISTES) ===")
    
    if not os.path.exists(CSV_PATH):
        print(f"Erreur : '{CSV_PATH}' non trouvé.")
        return
        
    df = pd.read_csv(CSV_PATH)
    
    X = df.drop(columns=['Client_ID', 'Attrition_Target'])
    y = df['Attrition_Target']
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    count_class_0 = np.sum(y_train == 0)
    count_class_1 = np.sum(y_train == 1)
    scale_pos_weight_value = count_class_0 / count_class_1
    print(f"\nRapport de déséquilibre (scale_pos_weight) : {scale_pos_weight_value:.2f}")
    
    
    param_grid = {
        'max_depth': [3, 5],
        'learning_rate': [0.05, 0.1],
        'n_estimators': [50, 100]
    }
    
    print("\nLancement de GridSearchCV (CV=3)...")
    xgb_base = XGBClassifier(
        scale_pos_weight=scale_pos_weight_value,
        random_state=42,
        eval_metric='logloss',
        n_jobs=-1
    )
    
    start_time = time.time()
    grid_search = GridSearchCV(
        estimator=xgb_base,
        param_grid=param_grid,
        cv=3,
        scoring='roc_auc',
        verbose=1,
        n_jobs=-1
    )
    grid_search.fit(X_train, y_train)
    
    print(f"Recherche terminée en {time.time() - start_time:.2f} secondes.")
    print(f"Meilleurs hyperparamètres : {grid_search.best_params_}")
    print(f"Meilleur score ROC-AUC Train CV : {grid_search.best_score_:.4f}")
    
    # 5. Évaluation du modèle optimisé
    best_model = grid_search.best_estimator_
    
    print("\nÉvaluation du modèle optimisé sur le jeu de test...")
    y_pred = best_model.predict(X_test)
    y_pred_proba = best_model.predict_proba(X_test)[:, 1]
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    roc_auc = roc_auc_score(y_test, y_pred_proba)
    
    print("\n" + "="*50)
    print(" RÉSULTATS DU MODÈLE XGBOOST OPTIMISÉ")
    print("="*50)
    print(f"1. Accuracy  : {accuracy:.4%}")
    print(f"2. Precision : {precision:.4%}")
    print(f"3. Recall    (Sensibilité) : {recall:.4%}")
    print(f"4. F1-Score  : {f1:.4%}")
    print(f"5. ROC-AUC   : {roc_auc:.4f}")
    print("="*50)
    
    print("\nMatrice de confusion :")
    cm = confusion_matrix(y_test, y_pred)
    print(f"  [Vrais Actifs  : {cm[0,0]:<5}]  [Faux Churns : {cm[0,1]:<5}]")
    print(f"  [Faux Actifs  : {cm[1,0]:<5}]  [Vrais Churns : {cm[1,1]:<5}]")
    
    joblib.dump(best_model, MODEL_PATH)
    print(f"\nModèle sauvegardé sous : '{MODEL_PATH}'")

if __name__ == "__main__":
    main()
