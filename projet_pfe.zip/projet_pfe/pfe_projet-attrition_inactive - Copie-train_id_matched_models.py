import pandas as pd
import shap
import os
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import classification_report, roc_auc_score, accuracy_score, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt

# 1. Load datasets
print("Loading anonymized_data_T1.csv...")
t1 = pd.read_csv("c:/Users/widad/Desktop/pfe_/attrition_inactive - Copie/anonymized_data_T1_15062026.csv", sep=";")

print("Loading anonymized_data_T2.csv...")
t2 = pd.read_csv("c:/Users/widad/Desktop/pfe_/attrition_inactive - Copie/anonymized_dataT2_15062026.csv", sep=";")

# 2. Merge on client ID column '1'
print("Merging datasets on Client ID (column '1')...")
merged = pd.merge(t1, t2, on='1', suffixes=('_T1', '_T2'))
print(f"Merged shape: {merged.shape} ({len(merged)} overlapping clients)")

# 3. Calculate Target Y
c20 = merged['20_T2']
c21 = merged['21_T2']
c22 = merged['22_T2']

y = np.zeros(len(merged), dtype=int)
y[(c20 == 0) & (c21 == 0) & (c22 == 0)] = 1

print("\nTarget Y distribution for matched clients:")
print(pd.Series(y).value_counts())

# Save matched dataset
matched_t3 = merged[[col for col in merged.columns if col.endswith('_T1') or col == '1']].copy()
matched_t3['Y_target'] = y

matched_t3.to_csv(
    "c:/Users/widad/Desktop/pfe_/attrition_inactive - Copie/anonymized_data_T3_id_matched.csv",
    sep=";",
    index=False
)

print("Saved matched dataset to anonymized_data_T3_id_matched.csv")

# 4. Features Selection
X = matched_t3.drop(columns=['1', 'Y_target'])

if 'Unnamed: 0_T1' in X.columns:
    X = X.drop(columns=['Unnamed: 0_T1'])

if 'Unnamed: 0' in X.columns:
    X = X.drop(columns=['Unnamed: 0'])

X = X.apply(pd.to_numeric, errors='coerce')

print("\nFeatures dataset shape:")
print(X.shape)

print("\nNumber of features:")
print(len(X.columns))

# 5. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Imputation and Scaling
imputer = SimpleImputer(strategy='median')

X_train_imputed = imputer.fit_transform(X_train)
X_test_imputed = imputer.transform(X_test)

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train_imputed)
X_test_scaled = scaler.transform(X_test_imputed)

# 6. Models
models = {
    "Logistic Regression": LogisticRegression(
        max_iter=1000,
        class_weight='balanced',
        random_state=42
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=100,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    ),
    "XGBoost": XGBClassifier(
        use_label_encoder=False,
        eval_metric='logloss',
        random_state=42,
        n_jobs=-1
    )
}

# 7. Train and Evaluate
results = {}

for name, model in models.items():
    print(f"\nTraining {name} on Matched Data...")

    if name == "Logistic Regression":
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        y_prob = model.predict_proba(X_test_scaled)[:, 1]
    else:
        model.fit(X_train_imputed, y_train)
        y_pred = model.predict(X_test_imputed)
        y_prob = model.predict_proba(X_test_imputed)[:, 1]

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)

    results[name] = {
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1,
        "ROC-AUC": auc
    }

    print(f"Results for {name}:")
    print(f"  Accuracy:  {accuracy:.4f}")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall:    {recall:.4f}")
    print(f"  F1-Score:  {f1:.4f}")
    print(f"  ROC-AUC:   {auc:.4f}")
    print(classification_report(y_test, y_pred))

print("\n" + "=" * 50)
print("SUMMARY OF MODEL METRICS (CORRECTLY MATCHED)")
print("=" * 50)

summary_df = pd.DataFrame(results).T
print(summary_df)

import joblib
best_model_name = summary_df['ROC-AUC'].idxmax()
print(f"\nBest model based on ROC-AUC is: {best_model_name}")

# Save the best model and preprocessors
joblib.dump(models[best_model_name], "best_model.pkl")
joblib.dump(imputer, "imputer.pkl")
joblib.dump(scaler, "scaler.pkl")

# Save feature names
joblib.dump(list(X.columns), "feature_names.pkl")

print(f"Saved {best_model_name} as best_model.pkl")
print("Saved imputer.pkl, scaler.pkl, and feature_names.pkl")

# ==================================================
# SHAP - XGBOOST
# ==================================================

xgb_model = models["XGBoost"]

explainer_xgb = shap.TreeExplainer(xgb_model)
shap_values_xgb = explainer_xgb.shap_values(X_test_imputed)

plt.figure(figsize=(12,8))

shap.summary_plot(
    shap_values_xgb,
    X_test,
    show=False
)

plt.title("SHAP Summary Plot - XGBoost")

plt.savefig(
    "SHAP_XGBoost.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved: SHAP_XGBoost.png")


# ==================================================
# SHAP - RANDOM FOREST
# ==================================================

rf_model = models["Random Forest"]

explainer_rf = shap.TreeExplainer(rf_model)
shap_values_rf = explainer_rf.shap_values(X_test_imputed)

# Cas classification binaire
if isinstance(shap_values_rf, list):
    shap_values_rf = shap_values_rf[1]

# Cas nouvelles versions SHAP
if len(shap_values_rf.shape) == 3:
    shap_values_rf = shap_values_rf[:, :, 1]

shap.summary_plot(
    shap_values_rf,
    X_test,
    max_display=20,
    show=False
)

plt.title("SHAP Summary Plot - Random Forest")

plt.savefig(
    "SHAP_RandomForest.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved: SHAP_RandomForest.png")


# ==================================================
# SHAP - LOGISTIC REGRESSION
# ==================================================
lr_model = models["Logistic Regression"]

explainer_lr = shap.LinearExplainer(
    lr_model,
    X_train_scaled
)

shap_values_lr = explainer_lr.shap_values(
    X_test_scaled
)

X_test_scaled_df = pd.DataFrame(
    X_test_scaled,
    columns=X.columns
)

plt.figure(figsize=(12,8))

shap.summary_plot(
    shap_values_lr,
    X_test_scaled_df,
    max_display=20,
    show=False
)

plt.title("SHAP Summary Plot - Logistic Regression")

plt.savefig(
    "SHAP_LogisticRegression.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Saved: SHAP_LogisticRegression.png")