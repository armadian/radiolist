import streamlit as st
import requests
import json
import numpy as np
import pandas as pd
import io


# ─────────────────────────────────────────────
# 1. Configuration de la page
# ─────────────────────────────────────────────
st.set_page_config(
    page_title="Al Barid Bank – Analyse d'Attrition",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─────────────────────────────────────────────
# 2. CSS Premium Al Barid Bank
# ─────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');

    #MainMenu, footer, header { visibility: hidden; display: none; }
    section[data-testid="stSidebar"] { display: none !important; }
    [data-testid="collapsedControl"] { display: none !important; }

    /* Remove top spacing of Streamlit container */
    .stMainBlockContainer {
        padding-top: 0rem !important;
        margin-top: 0rem !important;
    }
    .block-container {
        padding-top: 0rem !important;
        margin-top: 0rem !important;
    }

    /* ── Model Switcher ── */
    .model-switcher-wrap {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
    }
    .model-switcher {
        display: flex;
        gap: 0;
        background: rgba(0,0,0,0.05);
        border-radius: 50px;
        padding: 4px;
        border: 1px solid rgba(254,194,0,0.25);
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }


    /* ── Animated Background ── */
    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }
    
    .stApp {
        background: linear-gradient(-45deg, #fdfbf7, #ffffff, #f4eee6, #faf8f5);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
        font-family: 'Outfit', sans-serif;
    }

    /* ── Header ── */
    .app-header {
        background: rgba(44, 36, 28, 0.95);
        backdrop-filter: blur(10px);
        padding: 16px 32px;
        border-radius: 0 0 16px 16px;
        margin-bottom: 20px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        display: flex;
        align-items: center;
        justify-content: space-between;
        border-bottom: 3px solid #fec200;
        transition: transform 0.3s ease;
    }
    .app-header:hover { transform: translateY(1px); }
    .app-header h1 { color: #fff; font-size: 1.45em; font-weight: 800; margin: 0; letter-spacing: -0.5px; }
    .app-header h1 span { color: #fec200; }
    .app-header p { color: rgba(255,255,255,0.75); font-size: 0.8em; margin: 4px 0 0 0; font-weight: 300;}
    @keyframes shine {
        0% { background-position: -200% center; }
        100% { background-position: 200% center; }
    }
    .header-badge {
        background: linear-gradient(120deg, rgba(254,194,0,0.1) 0%, rgba(254,194,0,0.25) 50%, rgba(254,194,0,0.1) 100%);
        background-size: 200% auto;
        animation: shine 4s linear infinite;
        border: 1px solid rgba(254,194,0,0.5);
        border-radius: 20px;
        padding: 5px 12px;
        color: #fec200;
        font-size: 0.72em;
        font-weight: 800;
        letter-spacing: 0.5px;
        box-shadow: 0 0 12px rgba(254,194,0,0.2);
        text-transform: uppercase;
    }

    /* ── Glassmorphism Containers ── */
    [data-testid="stFileUploader"], .dataframe-container, .info-card, [data-testid="stMetric"], .empty-state, .stChatMessage {
        background: rgba(255, 255, 255, 0.65) !important;
        backdrop-filter: blur(10px) !important;
        -webkit-backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.8) !important;
        box-shadow: 0 6px 20px rgba(31, 38, 135, 0.04) !important;
        border-radius: 12px !important;
        transition: all 0.25s ease !important;
    }

    /* ── Hover Effects ── */
    .info-card:hover, [data-testid="stMetric"]:hover {
        transform: translateY(-2px) scale(1.01);
        box-shadow: 0 8px 25px rgba(0,0,0,0.06) !important;
        border-color: rgba(254,194,0,0.3) !important;
    }
    
    .section-title {
        font-size: 0.65em;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: #5c4e40;
        margin: 12px 0 8px 0;
        padding-bottom: 4px;
        border-bottom: 1.5px solid rgba(254,194,0,0.35);
    }

    /* ── Info card internals ── */
    .info-card { padding: 6px 10px; margin-bottom: 5px; border-left: 3px solid #fec200 !important; border-radius: 8px !important; }
    .info-card .label { font-size: 0.62em; color: #888; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; }
    .info-card .value { font-size: 0.88em; color: #1a1a1a; font-weight: 700; margin-top: 1px; }

    /* ── Alert Pulse Animation ── */
    @keyframes pulseAlert {
        0% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.5); transform: scale(1); }
        50% { transform: scale(1.01); }
        70% { box-shadow: 0 0 0 15px rgba(231, 76, 60, 0); transform: scale(1); }
        100% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0); transform: scale(1); }
    }
    
    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-3px); }
        100% { transform: translateY(0px); }
    }

    /* ── Result Cards ── */
    .result-card {
        border-radius: 12px;
        padding: 16px 12px;
        text-align: center;
        margin-bottom: 12px;
        color: white;
        border: 1px solid rgba(255,255,255,0.2);
    }
    .result-high { 
        background: linear-gradient(135deg, #c0392b, #e74c3c); 
        animation: pulseAlert 2.5s infinite; 
    }
    .result-low  { 
        background: linear-gradient(135deg, #27ae60, #2ecc71); 
        animation: float 4s ease-in-out infinite;
        box-shadow: 0 6px 15px rgba(46, 204, 113, 0.2);
    }
    .result-card .risk-label { font-size: 0.68em; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; opacity: 0.9; }
    .result-card .risk-percent { font-size: 2.2em; font-weight: 800; line-height: 1; margin: 6px 0; text-shadow: 1px 1px 4px rgba(0,0,0,0.15); }
    .result-card .risk-verdict { font-size: 0.88em; font-weight: 600; opacity: 0.95; letter-spacing: 0.2px; }

    /* ── Buttons (global) ── */
    .stButton > button {
        background: linear-gradient(135deg, #fec200 0%, #f0b800 100%) !important;
        color: #1a1a1a !important;
        border: none !important;
        border-radius: 8px !important;
        padding: 6px 12px !important;
        font-size: 0.76em !important;
        font-weight: 700 !important;
        width: 100% !important;
        box-shadow: 0 2px 8px rgba(254,194,0,0.2), inset 0 1px 0 rgba(255,255,255,0.3) !important;
        transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1) !important;
        white-space: normal !important;
        height: auto !important;
        min-height: 40px !important;
    }
    .stButton > button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 12px rgba(254,194,0,0.3), inset 0 1px 0 rgba(255,255,255,0.3) !important;
    }
    .stButton > button:active {
        transform: translateY(1px) !important;
    }

    /* ── Chat Input ── */
    .stChatInputContainer {
        border-radius: 20px !important;
        border: 2px solid rgba(124,107,92,0.15) !important;
        background: rgba(255,255,255,0.9) !important;
        backdrop-filter: blur(10px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.03) !important;
        transition: all 0.25s ease !important;
    }
    .stChatInputContainer:focus-within {
        border-color: #fec200 !important;
        box-shadow: 0 6px 25px rgba(254,194,0,0.2) !important;
        transform: translateY(-1px);
    }

    /* ── Empty State ── */
    .empty-state { padding: 25px 15px; border: 2px dashed rgba(124,107,92,0.25) !important; }
    .empty-state .icon { font-size: 2.2em; animation: float 3s ease-in-out infinite; }
    .empty-state .title { font-size: 0.9em; color: #4a3e32; font-weight: 700; margin-top: 8px; }
    .empty-state .sub { font-size: 0.78em; color: #bbb; margin-top: 3px; }

    /* ── Entrance Animations ── */
    @keyframes slideUpFade {
        0% { opacity: 0; transform: translateY(20px); }
        100% { opacity: 1; transform: translateY(0); }
    }
    
    .info-card, .result-card, .stChatMessage, .empty-state, [data-testid="stMetric"] { 
        animation: slideUpFade 0.5s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; 
    }
    
    /* ── Sidebar Glassmorphism & Premium UI ── */
</style>

</style>
""", unsafe_allow_html=True)




FEATURE_COLUMNS = []  # Will be set after file upload based on dataset columns (exclude ID & target)

# ─────────────────────────────────────────────
# 4. Header
# ─────────────────────────────────────────────
st.markdown("""
<div class="app-header">
  <div>
    <h1>🏦 Assistant IA – <span>Al Barid Bank</span></h1>
    <p>Prédiction & Analyse du Risque d'Attrition Client via import de fichier</p>
  </div>
  <div class="header-badge">ANALYSE & PREDICTION & RECOMMENDATION</div>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────
# 5. Session State & Model Detection
# ─────────────────────────────────────────────
if "current_model" not in st.session_state:
    st.session_state.current_model = "Attrition Totale"

# Auto-detect model based on uploaded file features
if st.session_state.get("df_uploaded") is not None:
    df_cols = set(st.session_state.df_uploaded.columns)
    # Attrition Inactive models are characterized by _T1 or matched suffix features (e.g. 2_T1)
    # Let's check if any column contains "_T1"
    has_t1 = any("_T1" in str(col) for col in df_cols)
    if has_t1:
        if st.session_state.current_model != "Attrition Inactive":
            st.session_state.current_model = "Attrition Inactive"
            st.session_state.messages = [{"role": "assistant", "content": "🔄 **Modèle Attrition Inactive détecté automatiquement** d'après la structure des colonnes du fichier !"}]
    else:
        if st.session_state.current_model != "Attrition Totale":
            st.session_state.current_model = "Attrition Totale"
            st.session_state.messages = [{"role": "assistant", "content": "🔄 **Modèle Attrition Totale détecté automatiquement** d'après la structure des colonnes du fichier !"}]

model_choice = st.session_state.current_model
st.markdown(f"""
<div style="text-align: center; margin: 10px 0 20px 0;">
    <span style="background: rgba(212, 175, 55, 0.15); color: #d4af37; border: 1px solid rgba(212, 175, 55, 0.3); padding: 6px 16px; border-radius: 20px; font-weight: bold; font-size: 0.9em; letter-spacing: 0.5px;">
        🎯 Modèle Actif : {model_choice}
    </span>
</div>
""", unsafe_allow_html=True)

API_URL = "http://localhost:8000" if model_choice == "Attrition Totale" else "http://localhost:8001"

def generate_excel_download(df_results, batch_responses):
    df_excel = df_results.copy()
    id_col = 'Client_ID' if 'Client_ID' in df_results.columns else df_results.columns[0]
    for question, responses in batch_responses.items():
        col_name = f"Question: {question}"
        df_excel[col_name] = df_excel[id_col].astype(str).map(responses)
    
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        df_excel.to_excel(writer, index=False, sheet_name="Attrition_Recommandations")
    return buffer.getvalue()




if "df_uploaded" not in st.session_state:
    st.session_state.df_uploaded = None
if "uploaded_file_name" not in st.session_state:
    st.session_state.uploaded_file_name = None
if "uploaded_file_size" not in st.session_state:
    st.session_state.uploaded_file_size = 0
if "df_results" not in st.session_state:
    st.session_state.df_results = None
if "batch_responses" not in st.session_state:
    st.session_state.batch_responses = {}
if "selected_client" not in st.session_state:
    st.session_state.selected_client = None
if "last_prediction" not in st.session_state:
    st.session_state.last_prediction = None
if "messages" not in st.session_state:
    st.session_state.messages = [{
        "role": "assistant",
        "content": "👋 Bonjour ! Je suis votre assistant IA **Al Barid Bank**.\n\n📂 Chargez un fichier CSV ou Excel contenant les données clients, sélectionnez un client, puis je vous fournirai une analyse complète du risque d'attrition !"
    }]
if "pending_question" not in st.session_state:
    st.session_state.pending_question = None

# Restaurer FEATURE_COLUMNS depuis session_state après un rerun
if "feature_columns" in st.session_state and st.session_state.feature_columns:
    FEATURE_COLUMNS = st.session_state.feature_columns

# ─────────────────────────────────────────────
# 6. Layout principal
# ─────────────────────────────────────────────
col_left, col_mid, col_chat = st.columns([1.4, 1, 1.3])

# ═══════════════════════════════════════════════
# COLONNE GAUCHE : Import fichier + sélection client
# ═══════════════════════════════════════════════
with col_left:
    st.markdown('<div class="section-title">📂 Import du Fichier Client</div>', unsafe_allow_html=True)

    uploaded_file = st.file_uploader(
        "Chargez un fichier CSV ou Excel",
        type=["csv", "xlsx", "xls"],
        help="Le fichier doit contenir les mêmes colonnes que le dataset d'entraînement."
    )

    if uploaded_file is not None:
        try:
            # Si le fichier change (nom ou taille), réinitialiser les anciens résultats et charger le fichier
            if (st.session_state.uploaded_file_name != uploaded_file.name or 
                st.session_state.uploaded_file_size != uploaded_file.size):
                
                st.session_state.uploaded_file_name = uploaded_file.name
                st.session_state.uploaded_file_size = uploaded_file.size
                
                if uploaded_file.name.endswith(".csv"):
                    df = pd.read_csv(uploaded_file)
                else:
                    df = pd.read_excel(uploaded_file)
                
                st.session_state.df_uploaded = df
                st.session_state.df_results = None
                st.session_state.batch_responses = {}
            else:
                df = st.session_state.df_uploaded

            # Déterminer dynamiquement les colonnes de caractéristiques
            feature_cols = [c for c in df.columns if c not in ['Client_ID', 'Attrition_Target']]
            st.session_state.feature_columns = feature_cols
            FEATURE_COLUMNS = feature_cols

            # Détecter le modèle immédiatement à l'import
            df_cols = set(df.columns)
            has_t1 = any("_T1" in str(col) for col in df_cols)
            new_model = "Attrition Inactive" if has_t1 else "Attrition Totale"
            
            if st.session_state.get("current_model") != new_model:
                st.session_state.current_model = new_model
                st.session_state.last_prediction = None  # Clear previous predictions
                st.rerun()

            st.success(f"✅ Fichier chargé avec succès : **{len(df)} client(s)** trouvé(s).")
        except Exception as e:
            st.error(f"❌ Erreur lors de la lecture du fichier : {e}")

    if st.session_state.df_uploaded is not None:
        df = st.session_state.df_uploaded

        # ── Aperçu du fichier ──
        st.markdown('<div class="section-title">👁️ Aperçu du Fichier</div>', unsafe_allow_html=True)
        if st.session_state.current_model == "Attrition Totale":
            preview_cols = [c for c in ['Client_ID', 'Age', 'Gender', 'Region', 'Seniority_Months', 'Customer_Segment'] if c in df.columns]
        else:
            preview_cols = df.columns[:6]
        st.dataframe(df[preview_cols].head(10), use_container_width=True, height=220)

        # ── Sélection du client ──
        st.markdown('<div class="section-title">🎯 Sélectionner un Client</div>', unsafe_allow_html=True)
        if 'Client_ID' in df.columns:
            client_options = df['Client_ID'].astype(str).tolist()
            client_label = "Client ID"
        else:
            client_options = [f"Ligne {i+1}" for i in range(len(df))]
            client_label = "Numéro de ligne"

        selected_label = st.selectbox(f"Choisir un client ({client_label})", client_options)
        selected_idx = client_options.index(selected_label)
        client_row = df.iloc[selected_idx]

        # ── Fiche du client sélectionné ──
        st.markdown('<div class="section-title">🪪 Données du Client Sélectionné</div>', unsafe_allow_html=True)
        if st.session_state.current_model == "Attrition Totale":
            key_fields = {
                "Âge": "Age",
                "Genre": "Gender",
                "Région": "Region",
                "Ancienneté (mois)": "Seniority_Months",
                "Segment": "Customer_Segment",
                "App BBM": "Has_BBM_App",
                "Carte Active": "Has_Active_Card",
                "Réclamations 6M": "Complaint_Count_Last_6M",
                "Chute Salaire": "Salary_Drop_Ratio",
            }
        else:
            # Pour le modèle inactif, trouver les 8 premières variables qui ne sont pas égales à 0 (ou qui sont les plus pertinentes/non vides)
            key_fields = {}
            non_zero_cols = []
            for col in FEATURE_COLUMNS:
                val = client_row.get(col, 0)
                try:
                    # Si c'est numérique et non nul, on le priorise
                    if pd.notna(val) and float(val) != 0.0:
                        non_zero_cols.append(col)
                except ValueError:
                    if pd.notna(val) and val != "":
                        non_zero_cols.append(col)
            
            # Si on n'a pas assez de variables non nulles, on complète avec les premières variables du fichier
            for col in FEATURE_COLUMNS:
                if len(non_zero_cols) >= 8:
                    break
                if col not in non_zero_cols:
                    non_zero_cols.append(col)
                    
            for col in non_zero_cols[:8]:
                key_fields[f"Var: {col}"] = col

        col_a, col_b = st.columns(2)
        fields_list = list(key_fields.items())
        for i, (label, col_name) in enumerate(fields_list):
            value = client_row.get(col_name, "N/A")
            if isinstance(value, float):
                value = f"{value:.3f}"
            target_col = col_a if i % 2 == 0 else col_b
            target_col.markdown(f"""
            <div class="info-card">
                <div class="label">{label}</div>
                <div class="value">{value}</div>
            </div>""", unsafe_allow_html=True)

        # ── Bouton Prédire ──
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔍 Prédire le Risque d'Attrition"):
            try:
                missing_cols = [c for c in FEATURE_COLUMNS if c not in df.columns]
                if missing_cols:
                    st.error(f"⚠️ Colonnes manquantes dans le fichier : {missing_cols}")
                else:
                    X_input = [client_row[FEATURE_COLUMNS].replace({np.nan: None}).to_dict()]

                    with st.spinner("⏳ Prédiction en cours via l'API..."):
                        api_res = requests.post(f"{API_URL}/predict/batch_raw", json=X_input)

                    if api_res.status_code == 200:
                        res_data = api_res.json()
                        proba = res_data["probabilities"][0]
                        risk_pct = round(proba * 100, 1)
                        prediction = res_data["predictions"][0]

                        st.session_state.last_prediction = {
                            "client_id": selected_label,
                            "risk_pct": risk_pct,
                            "prediction": prediction,
                            "model": st.session_state.current_model,
                            "row_data": client_row.to_dict()
                        }
                        # Réinitialiser le chat pour ce nouveau client
                        st.session_state.messages = [{
                            "role": "assistant",
                            "content": f"✅ Analyse du client **{selected_label}** terminée. Le modèle XGBoost a calculé un risque d'attrition de **{risk_pct}%**.\n\nPosez-moi vos questions pour comprendre ce résultat et obtenir des recommandations !"
                        }]
                        st.rerun()
                    else:
                        st.error(f"Erreur API : {api_res.text}")
            except Exception as e:
                st.error(f"Erreur lors de la prédiction : {e}")

    else:
        # État vide
        st.markdown("""
        <div class="empty-state">
            <div class="icon">📂</div>
            <div class="title">Aucun fichier chargé</div>
            <div class="sub">Importez un fichier CSV ou Excel pour commencer l'analyse</div>
        </div>""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════
# COLONNE MILIEU : Résultat + Analyse par lot
# ═══════════════════════════════════════════════
with col_mid:
    st.markdown('<div class="section-title">📊 Résultat de la Prédiction</div>', unsafe_allow_html=True)

    if st.session_state.last_prediction:
        p = st.session_state.last_prediction
        risk_pct = p["risk_pct"]
        prediction = p["prediction"]

        card_class = "result-high" if prediction == 1 else "result-low"
        verdict = "🚨 Risque Élevé d'Attrition" if prediction == 1 else "✅ Client Stable"

        st.markdown(f"""
        <div class="result-card {card_class}">
            <div class="risk-label">Client {p['client_id']}</div>
            <div class="risk-label" style="margin-top:4px;">Probabilité d'Attrition</div>
            <div class="risk-percent">{risk_pct}%</div>
            <div class="risk-verdict">{verdict}</div>
        </div>""", unsafe_allow_html=True)

        # Facteurs clés
        st.markdown('<div class="section-title">📌 Facteurs Clés du Profil</div>', unsafe_allow_html=True)
        
        indicators = []
        if p["model"] == "Attrition Totale":
            indicators = [
                ("📅 Ancienneté", f"{p['row_data'].get('Seniority_Months', 'N/A')} mois"),
                ("🧩 Segment", f"Segment {p['row_data'].get('Customer_Segment', 'N/A')}"),
                ("📣 Réclamations 6M", str(p['row_data'].get('Complaint_Count_Last_6M', 0))),
                ("📣 Réclamations 1M", str(p['row_data'].get('Complaint_Count_Last_1M', 0))),
                ("💸 Salaire Domicilié", "Oui ✅" if p['row_data'].get('Has_Salary_Domestication') else "Non ❌"),
                ("📱 App BBM", "Oui ✅" if p['row_data'].get('Has_BBM_App') else "Non ❌"),
                ("💳 Carte Active", "Oui ✅" if p['row_data'].get('Has_Active_Card') else "Non ❌"),
            ]
        else:
            for i, col in enumerate(FEATURE_COLUMNS):
                if i >= 10: break
                val = p['row_data'].get(col, 'N/A')
                if isinstance(val, float): val = f"{val:.3f}"
                indicators.append((f"📌 {col}", str(val)))

        for label, value in indicators:
            st.markdown(f"""
            <div class="info-card">
                <div class="label">{label}</div>
                <div class="value">{value}</div>
            </div>""", unsafe_allow_html=True)

    else:
        st.markdown("""
        <div class="empty-state">
            <div class="icon">📊</div>
            <div class="title">En attente d'analyse</div>
            <div class="sub">Importez un fichier et sélectionnez un client pour voir le résultat</div>
        </div>""", unsafe_allow_html=True)

    # ── Analyse par lot ──
    if st.session_state.df_uploaded is not None:
        df = st.session_state.df_uploaded
        missing = [c for c in FEATURE_COLUMNS if c not in df.columns]

        if not missing:
            st.markdown('<div class="section-title">📋 Analyse de Tous les Clients</div>', unsafe_allow_html=True)
            


            if st.session_state.df_results is not None:
                df_results = st.session_state.df_results
                id_col = 'Client_ID' if 'Client_ID' in df_results.columns else df_results.columns[0]
                display_cols = [id_col, "Risque_Attrition_%", "Verdict"]
                st.dataframe(
                    df_results[display_cols].sort_values("Risque_Attrition_%", ascending=False),
                    use_container_width=True,
                    height=200
                )
                
                col_dl1, col_dl2 = st.columns(2)
                csv_export = df_results.to_csv(index=False).encode("utf-8")
                col_dl1.download_button(
                    label="⬇️ Télécharger (CSV)",
                    data=csv_export,
                    file_name="resultats_attrition.csv",
                    mime="text/csv"
                )
                
                if st.session_state.batch_responses:
                    excel_data = generate_excel_download(df_results, st.session_state.batch_responses)
                    col_dl2.download_button(
                        label="🟢 Télécharger Excel + Réponses IA",
                        data=excel_data,
                        file_name="attrition_avec_reponses_ia.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
                else:
                    buffer_simple = io.BytesIO()
                    with pd.ExcelWriter(buffer_simple, engine='openpyxl') as writer:
                        df_results.to_excel(writer, index=False)
                    col_dl2.download_button(
                        label="📄 Télécharger Excel simple",
                        data=buffer_simple.getvalue(),
                        file_name="resultats_attrition.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )

            if st.button("⚡ Prédire pour tout le fichier", key="btn_predict_all"):
                X_all = df[FEATURE_COLUMNS]
                data_json = X_all.replace({np.nan: None}).to_dict(orient="records")

                with st.spinner("⚡ Traitement de l'ensemble du fichier via l'API..."):
                    api_res = requests.post(f"{API_URL}/predict/batch_raw", json=data_json)

                if api_res.status_code == 200:
                    res_data = api_res.json()
                    probas = np.array(res_data["probabilities"])
                    preds = np.array(res_data["predictions"])

                    df_results = df.copy()
                    df_results["Risque_Attrition_%"] = (probas * 100).round(1)
                    df_results["Verdict"] = ["🔴 À risque" if p == 1 else "🟢 Stable" for p in preds]

                    st.session_state.df_results = df_results
                    st.session_state.batch_responses = {} # reset recommendations on new prediction
                    st.rerun()
                else:
                    st.error(f"Erreur API : {api_res.text}")


# ═══════════════════════════════════════════════
# COLONNE DROITE : Chatbot IA avec questions suggérées
# ═══════════════════════════════════════════════
with col_chat:
    st.markdown('<div class="section-title">🤖 Assistant IA – Analyse & Conseils</div>', unsafe_allow_html=True)

    if st.session_state.df_results is not None and st.session_state.batch_responses:
        try:
            excel_data = generate_excel_download(st.session_state.df_results, st.session_state.batch_responses)
            st.download_button(
                label="🟢 Télécharger le fichier Excel (avec Réponses)",
                data=excel_data,
                file_name="resultats_attrition_ia.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="btn_download_chat_excel"
            )
        except Exception as e:
            st.error(f"Erreur génération Excel: {e}")

    batch_mode = False
    if st.session_state.df_results is not None:
        st.markdown("""
        <div style="background: rgba(254, 194, 0, 0.08); border: 1px solid rgba(254,194,0,0.25); padding: 8px 12px; border-radius: 8px; margin-bottom: 10px;">
            <span style="color: #fec200; font-weight: 700; font-size: 0.8em; letter-spacing: 0.5px;">⚡ MODE MULTI-CLIENTS ACTIF ({n_clients} clients)</span>
        </div>
        """.format(n_clients=len(st.session_state.df_results)), unsafe_allow_html=True)
        batch_mode = st.checkbox("💬 Répondre pour tous les clients du fichier", value=True)

    # ── Construire le contexte système ──
    pred_ctx = ""
    if batch_mode and st.session_state.df_results is not None:
        df_res = st.session_state.df_results
        id_col = 'Client_ID' if 'Client_ID' in df_res.columns else df_res.columns[0]
        
        client_summaries = []
        for idx, row in df_res.iterrows():
            cid = row[id_col]
            pct = row.get("Risque_Attrition_%", 0.0)
            verd = row.get("Verdict", "Stable")
            
            # Si le modèle est Attrition Totale, on inclut également les données de départ importantes !
            if st.session_state.current_model == "Attrition Totale":
                feats = []
                key_cols = ['Age', 'Gender', 'Region', 'Seniority_Months', 'Customer_Segment', 'Has_BBM_App', 'Has_Active_Card', 'Complaint_Count_Last_6M', 'Salary_Drop_Ratio']
                for col in key_cols:
                    if col in row:
                        feats.append(f"{col}={row[col]}")
                client_summaries.append(f"- Client {cid}: Risque={pct}%, Verdict={verd} ({', '.join(feats)})")
            else:
                # Modèle Attrition Inactive : se baser UNIQUEMENT sur le résultat de la prédiction
                client_summaries.append(f"- Client {cid}: Risque={pct}%, Verdict={verd}")
            
        pred_ctx = f"""
[MODE MULTI-CLIENTS ACTIF - MODELE: {st.session_state.current_model}]
L'utilisateur a importé un fichier de {len(df_res)} clients et a prédit leur risque d'attrition.
Voici la liste complète des clients et les résultats associés :
{chr(10).join(client_summaries)}

Réponds directement aux questions sur l'ensemble de ces clients et propose des plans stratégiques en te basant sur ces données.
"""
    elif st.session_state.last_prediction:
        p = st.session_state.last_prediction
        niveau = "ÉLEVÉ (client à risque d'attrition)" if p["prediction"] == 1 else "FAIBLE (client stable)"
        pred_ctx = f"""
[MODE CLIENT UNIQUE ACTIF]
La dernière analyse concerne le client ID : {p['client_id']}.
Modèle utilisé : {p['model']}.
Résultat :
- Probabilité d'attrition : {p['risk_pct']}%
- Verdict : {niveau}
- Données client : {str(p['row_data'])[:500]} ...
"""
    elif st.session_state.df_uploaded is not None:
        pred_ctx = f"""
[FICHIER IMPORTÉ MAIS PAS DE PRÉDICTION]
L'utilisateur a déjà importé un fichier contenant {len(st.session_state.df_uploaded)} clients.
Les prédictions n'ont pas encore été lancées. Ne demande pas d'importer le fichier à nouveau. Invite-le plutôt à lancer l'analyse en cliquant sur les boutons de prédiction ('Prédire le Risque d'Attrition' à gauche ou '⚡ Prédire pour tout le fichier' au milieu).
"""
    else:
        pred_ctx = """
[AUCUN FICHIER IMPORTÉ]
Aucun fichier client n'a été chargé pour le moment. Invite poliment l'utilisateur à importer un fichier CSV ou Excel de test en utilisant le module à gauche.
"""

    system_content = f"""Tu es un expert en Data Science bancaire et en stratégie de fidélisation client, travaillant pour Al Barid Bank (banque marocaine spécialisée dans les services postaux et financiers).
Tu analyses des profils clients pour prédire et prévenir leur risque d'attrition.
Le modèle utilisé est un XGBoost optimisé.

{pred_ctx}

Tes responsabilités :
1. Expliquer clairement les résultats des prédictions (qu'il s'agisse d'un client unique ou de tous les clients du fichier importé).
2. Identifier les signaux d'alarme et proposer des recommandations stratégiques ciblées d'aide à la décision.
3. Formuler des plans de rétention personnalisés pour les clients à risque.
Réponds toujours en français. Ne propose pas d'importer de fichier s'il est déjà importé ou si des prédictions sont affichées."""

    # ── Questions pré-définies cliquables ──
    if batch_mode:
        suggestions = [
            "📋 Plan de rétention suggéré (Tous)",
            "🎁 Actions & Offres ciblées (Tous)",
            "🎯 Recommandations d'aide à la décision (Tous)",
            "📞 Script d'appel recommandé (Tous)",
        ]
        for i in range(0, len(suggestions), 2):
            cols_q = st.columns(2)
            for j in range(2):
                if i + j < len(suggestions):
                    if cols_q[j].button(suggestions[i + j], key=f"sugg_batch_{i+j}"):
                        st.session_state.pending_question = suggestions[i + j]
    elif st.session_state.last_prediction:
        p = st.session_state.last_prediction

        if p["prediction"] == 1:
            suggestions = [
                f"📋 Plan de rétention suggéré pour {p['client_id']}",
                "🎁 3 offres ciblées pour retenir ce profil",
                "🎯 Recommandations urgentes d'aide à la décision",
                "📞 Script d'appel conseillé pour ce client",
            ]
        else:
            suggestions = [
                f"📈 Opportunités de cross-selling pour {p['client_id']}",
                "💡 Actions pour renforcer davantage sa fidélité",
                "🎯 Recommandations stratégiques d'aide à la décision",
                "🛡️ Indicateurs de vigilance à surveiller",
            ]

        for i in range(0, len(suggestions), 2):
            cols_q = st.columns(2)
            for j in range(2):
                if i + j < len(suggestions):
                    if cols_q[j].button(suggestions[i + j], key=f"sugg_{i+j}"):
                        st.session_state.pending_question = suggestions[i + j]

    # ── Fonction helper pour appeler Ollama (Single client) ──
    def call_ollama(user_prompt):
        st.session_state.messages.append({"role": "user", "content": user_prompt})
        st.chat_message("user").markdown(user_prompt)
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            full_response = ""
            sys_prompt = {"role": "system", "content": system_content}
            ollama_msgs = [sys_prompt] + [
                {"role": m["role"], "content": m["content"]}
                for m in st.session_state.messages
            ]
            try:
                response = requests.post(
                    "http://localhost:11434/api/chat",
                    json={"model": "llama3:8b", "messages": ollama_msgs, "stream": True},
                    stream=True
                )
                if response.status_code == 200:
                    for line in response.iter_lines():
                        if line:
                            rj = json.loads(line.decode("utf-8"))
                            if "message" in rj and "content" in rj["message"]:
                                full_response += rj["message"]["content"]
                                message_placeholder.markdown(full_response + "▌")
                    message_placeholder.markdown(full_response)
                    st.session_state.messages.append({"role": "assistant", "content": full_response})
                else:
                    message_placeholder.error(f"Erreur Ollama (Code {response.status_code})")
            except requests.exceptions.ConnectionError:
                message_placeholder.error("❌ Ollama n'est pas accessible. Lancez Ollama sur votre machine.")
            except Exception as e:
                message_placeholder.error(f"Erreur : {e}")

    # ── Fonction helper pour appeler Ollama (Batch clients) ──
    def call_ollama_batch(user_prompt):
        st.session_state.messages.append({"role": "user", "content": user_prompt})
        st.chat_message("user").markdown(user_prompt)
        
        with st.chat_message("assistant"):
            status_placeholder = st.empty()
            message_placeholder = st.empty()
            
            df_res = st.session_state.df_results
            id_col = 'Client_ID' if 'Client_ID' in df_res.columns else df_res.columns[0]
            n_clients = len(df_res)
            
            if user_prompt not in st.session_state.batch_responses:
                st.session_state.batch_responses[user_prompt] = {}
                
            responses_summary = []
            
            for index, row in df_res.iterrows():
                client_id = str(row[id_col])
                status_placeholder.info(f"⏳ Génération pour le client **{client_id}** ({index+1}/{n_clients})...")
                
                # Context specific to this client
                proba = row.get("Risque_Attrition_%", 0)
                verdict = row.get("Verdict", "Stable")
                
                # Check model to decide context
                if st.session_state.current_model == "Attrition Totale":
                    feat_summary = []
                    key_cols = ['Age', 'Gender', 'Region', 'Seniority_Months', 'Customer_Segment', 'Has_BBM_App', 'Has_Active_Card', 'Complaint_Count_Last_6M', 'Salary_Drop_Ratio']
                    for col in key_cols:
                        if col in row:
                            feat_summary.append(f"{col}: {row[col]}")
                    feat_str = ", ".join(feat_summary)
                    client_ctx = f"Client ID: {client_id}, Risque: {proba}% ({verdict}). Données de départ: {feat_str}."
                else:
                    # Inactive model: ONLY prediction results
                    client_ctx = f"Client ID: {client_id}, Risque: {proba}% ({verdict})."
                
                sys_content_client = f"""Tu es un expert en Data Science bancaire et en stratégie de fidélisation client chez Al Barid Bank.
Données du client : {client_ctx}
Réponds à la question suivante de manière très concise (2 à 3 phrases maximum), concrète et adaptée à son profil : {user_prompt}"""
                
                ollama_msgs = [
                    {"role": "system", "content": sys_content_client},
                    {"role": "user", "content": user_prompt}
                ]
                
                try:
                    response = requests.post(
                        "http://localhost:11434/api/chat",
                        json={"model": "llama3:8b", "messages": ollama_msgs, "stream": False},
                        timeout=30
                    )
                    if response.status_code == 200:
                        rj = response.json()
                        client_response = rj["message"]["content"].strip()
                    else:
                        client_response = f"Erreur de génération (Code {response.status_code})"
                except Exception as e:
                    client_response = f"Erreur de génération : {e}"
                
                st.session_state.batch_responses[user_prompt][client_id] = client_response
                responses_summary.append(f"👤 **Client {client_id}** ({verdict} - {proba}%)\n\n> {client_response}")
            
            status_placeholder.empty()
            st.success("✅ Réponses générées pour tous les clients !")
            full_summary_text = "\n\n---\n\n".join(responses_summary)
            message_placeholder.markdown(full_summary_text)
            st.session_state.messages.append({"role": "assistant", "content": full_summary_text})
            st.rerun()

    # ── Afficher l'historique des messages ──
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # ── Traiter une question suggérée cliquée ──
    if st.session_state.pending_question:
        question = st.session_state.pending_question
        st.session_state.pending_question = None
        call_ollama(question)

    # ── Saisie libre ──
    if prompt := st.chat_input("Posez votre question sur ce profil..."):
        call_ollama(prompt)
