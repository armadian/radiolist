import requests

print("=== TEST API ATTRITION INACTIVE ===")

try:
    r = requests.get("http://localhost:8001/features")
    r.raise_for_status()
    features = r.json()["features"]
    print(f"L'API demande {len(features)} features.")
    
    # Création de données bidon pour le test
    dummy_data = {f: 0.0 for f in features}
    
    r = requests.post("http://localhost:8001/predict", json={"features": dummy_data})
    r.raise_for_status()
    result = r.json()
    print("Test de prédiction réussi !")
    print("Résultat:", result)
except Exception as e:
    print(f"Erreur lors du test: {e}")
