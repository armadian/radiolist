import pandas as pd
import numpy as np
import os
import joblib
import time
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

CSV_PATH = "attrition_dataset_30000.csv"
MODEL_PATH = "lr_model.pkl"

def main():
    print("=== ENTRAÎNEMENT DU MODÈLE : RÉGRESSION LOGISTIQUE (SUR DONNÉES RÉALISTES) ===")
    
    if not os.path.exists(CSV_PATH):
        raise FileNotFoundError(f"Fichier de données '{CSV_PATH}' non trouvé.")
        
    # 1. Chargement des données
    df = pd.read_csv(CSV_PATH)
    
    # 2. Préparation des caractéristiques et de la cible
    X = df.drop(columns=['Client_ID', 'Attrition_Target'])
    y = df['Attrition_Target']
    
    # 3. Séparation Train/Test
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # 4. Entraînement avec StandardScaler
    print("\nEntraînement de la Régression Logistique...")
    start_train = time.time()
    
    lr_pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', LogisticRegression(max_iter=1000, random_state=42))
    ])
    lr_pipeline.fit(X_train, y_train)
    
    print(f"Modèle entraîné en {time.time() - start_train:.2f} secondes.")
    
    # 5. Sauvegarde
    joblib.dump(lr_pipeline, MODEL_PATH)
    print(f"Modèle sauvegardé dans : '{MODEL_PATH}'")

if __name__ == "__main__":
    main()
