"""
FastAPI pour le meilleur modèle d'attrition inactive.
"""
import os
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any, List

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "best_model.pkl")
IMPUTER_PATH = os.path.join(BASE_DIR, "imputer.pkl")
SCALER_PATH = os.path.join(BASE_DIR, "scaler.pkl")
FEATURES_PATH = os.path.join(BASE_DIR, "feature_names.pkl")

# Chargement des objets au démarrage
def load_artifacts():
    if not os.path.exists(MODEL_PATH):
        raise RuntimeError("Modèle introuvable. Veuillez exécuter train_id_matched_models.py dans le dossier parent.")
    
    m = joblib.load(MODEL_PATH)
    i = joblib.load(IMPUTER_PATH)
    f = joblib.load(FEATURES_PATH)
    
    s = None
    if os.path.exists(SCALER_PATH):
        s = joblib.load(SCALER_PATH)
        
    return m, i, s, f

model, imputer, scaler, feature_names = load_artifacts()

app = FastAPI(
    title="🏦 API Prédiction Attrition Inactive",
    description="API pour le meilleur modèle issu du dataset T1/T2 (matched).",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PredictRequest(BaseModel):
    features: Dict[str, float]

    class Config:
        json_schema_extra = {
            "example": {
                "features": {
                    "2_T1": 45.0,
                    "3_T1": 1.0,
                    "4_T1": 120.0
                }
            }
        }

class BatchPredictRequest(BaseModel):
    features_list: List[Dict[str, float]]


@app.get("/health", tags=["Monitoring"])
def health():
    return {
        "status": "healthy",
        "model_type": type(model).__name__,
        "n_features": len(feature_names)
    }

@app.get("/features", tags=["Monitoring"])
def get_features():
    return {
        "n_features": len(feature_names),
        "features": feature_names
    }

@app.post("/predict", tags=["Prédiction"])
def predict(request: PredictRequest):
    # Vérification des features
    missing = [f for f in feature_names if f not in request.features]
    if missing:
        raise HTTPException(
            status_code=400, 
            detail=f"Features manquantes ({len(missing)} au total). Exemples : {missing[:5]}"
        )
    
    # Création du DataFrame dans le bon ordre
    df = pd.DataFrame([request.features])
    df = df[feature_names]
    
    # Prétraitement
    X = imputer.transform(df)
    
    # Seul Logistic Regression utilisait le scaler dans le script
    if type(model).__name__ == "LogisticRegression" and scaler:
        X = scaler.transform(X)
        
    # Prédiction
    pred = int(model.predict(X)[0])
    proba = float(model.predict_proba(X)[0][1])
    
    # Calcul du risque
    if proba < 0.25: risk = "Faible"
    elif proba < 0.50: risk = "Moyen"
    elif proba < 0.75: risk = "Élevé"
    else: risk = "Critique"
    
    return {
        "prediction": pred,
        "label": "Churner" if pred == 1 else "Actif",
        "probability": round(proba, 4),
        "risk_level": risk
    }

@app.post("/predict/batch_raw", tags=["Prédiction"])
def predict_batch_raw(requests_list: List[Dict[str, Any]]):
    if not requests_list:
        return {"predictions": [], "probabilities": []}
    
    # Création du DataFrame
    df = pd.DataFrame(requests_list)
    
    # Garder uniquement les features nécessaires dans le bon ordre
    missing = [f for f in feature_names if f not in df.columns]
    if missing:
        raise HTTPException(status_code=400, detail=f"Features manquantes : {missing[:5]}")
        
    df = df[feature_names]
    
    X = imputer.transform(df)
    if type(model).__name__ == "LogisticRegression" and scaler:
        X = scaler.transform(X)
        
    preds = model.predict(X)
    probas = model.predict_proba(X)[:, 1]
    
    return {
        "predictions": preds.tolist(),
        "probabilities": probas.tolist()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8001, reload=True)
