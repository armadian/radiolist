"""
API FastAPI pour la prédiction d'attrition client (Churn)
Modèle : XGBoost
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import List, Optional
from datetime import datetime

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import math

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "optimized_xgb_model.pkl")  # Le modèle optimisé avec 98 features

FEATURE_COLUMNS = [
    "Age", "Gender", "Region", "Urban_Rural", "Seniority_Months",
    "Customer_Segment", "Has_Salary_Domestication", "Has_BBM_App",
    "Has_Active_Card", "Has_Savings_CEN", "Has_Consumer_Loan",
    "Has_Mortgage_Loan", "Has_Gold_Card",
    "Complaint_Count_Last_6M", "Complaint_Count_Last_1M",
    "CC_Balance_M1", "CC_Balance_M2", "CC_Balance_M3",
    "CC_Balance_M4", "CC_Balance_M5", "CC_Balance_M6",
    "Credit_Flow_M1", "Credit_Flow_M2", "Credit_Flow_M3",
    "Credit_Flow_M4", "Credit_Flow_M5", "Credit_Flow_M6",
    "Debit_Flow_M1", "Debit_Flow_M2", "Debit_Flow_M3",
    "Debit_Flow_M4", "Debit_Flow_M5", "Debit_Flow_M6",
    "BBM_Connections_M1", "BBM_Connections_M2", "BBM_Connections_M3",
    "BBM_Connections_M4", "BBM_Connections_M5", "BBM_Connections_M6",
    "Card_Online_Count_M1", "Card_Online_Count_M2", "Card_Online_Count_M3",
    "Card_Online_Count_M4", "Card_Online_Count_M5", "Card_Online_Count_M6",
    "Card_Online_Vol_M1", "Card_Online_Vol_M2", "Card_Online_Vol_M3",
    "Card_Online_Vol_M4", "Card_Online_Vol_M5", "Card_Online_Vol_M6",
    "ATM_Withdrawals_Count_M1", "ATM_Withdrawals_Count_M2", "ATM_Withdrawals_Count_M3",
    "ATM_Withdrawals_Count_M4", "ATM_Withdrawals_Count_M5", "ATM_Withdrawals_Count_M6",
    "ATM_Withdrawals_Vol_M1", "ATM_Withdrawals_Vol_M2", "ATM_Withdrawals_Vol_M3",
    "ATM_Withdrawals_Vol_M4", "ATM_Withdrawals_Vol_M5", "ATM_Withdrawals_Vol_M6",
    "POS_Payments_Count_M1", "POS_Payments_Count_M2", "POS_Payments_Count_M3",
    "POS_Payments_Count_M4", "POS_Payments_Count_M5", "POS_Payments_Count_M6",
    "POS_Payments_Vol_M1", "POS_Payments_Vol_M2", "POS_Payments_Vol_M3",
    "POS_Payments_Vol_M4", "POS_Payments_Vol_M5", "POS_Payments_Vol_M6",
    "Branch_Trans_Count_M1", "Branch_Trans_Count_M2", "Branch_Trans_Count_M3",
    "Branch_Trans_Count_M4", "Branch_Trans_Count_M5", "Branch_Trans_Count_M6",
    "Branch_Trans_Vol_M1", "Branch_Trans_Vol_M2", "Branch_Trans_Vol_M3",
    "Branch_Trans_Vol_M4", "Branch_Trans_Vol_M5", "Branch_Trans_Vol_M6",
    "Interbank_Transfers_Count_M1", "Interbank_Transfers_Count_M2",
    "Interbank_Transfers_Count_M3", "Interbank_Transfers_Count_M4",
    "Interbank_Transfers_Count_M5", "Interbank_Transfers_Count_M6",
    "Balance_Trend_Ratio", "BBM_Connections_Drop_Ratio",
    "Card_Payments_Drop_Ratio", "Creditor_Flow_Drop", "Salary_Drop_Ratio",
]

# ─────────────────────────────────────────────
# Chargement du modèle au démarrage
# ─────────────────────────────────────────────
def load_model(path: str):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Modèle introuvable : {path}. Lancez train_xgboost.py d'abord.")
    return joblib.load(path)

model = load_model(MODEL_PATH)
model_name = "xgb_model (98 features)"
model_loaded_at = datetime.now().isoformat()

# ─────────────────────────────────────────────
# Application FastAPI
# ─────────────────────────────────────────────
app = FastAPI(
    title="🏦 API Prédiction d'Attrition Client",
    description="""
## API de prédiction de churn bancaire (Attrition Client)
Modèle XGBoost entraîné sur le dataset de 100 colonnes (98 features en entrée).
    """,
    version="1.0.0",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────
# Schémas Pydantic
# ─────────────────────────────────────────────
class ClientData(BaseModel):
    """Données d'un client pour la prédiction (98 features)."""
    client_id: Optional[str] = Field(None, example="CLI_00001", description="Identifiant optionnel")

    Age: int = Field(..., example=42)
    Gender: int = Field(..., example=1)
    Region: int = Field(..., example=3)
    Urban_Rural: int = Field(..., example=1)
    Seniority_Months: int = Field(..., example=60)
    Customer_Segment: int = Field(..., example=2)
    Has_Salary_Domestication: int = Field(..., example=1)
    Has_BBM_App: int = Field(..., example=1)
    Has_Active_Card: int = Field(..., example=1)
    Has_Savings_CEN: int = Field(..., example=0)
    Has_Consumer_Loan: int = Field(..., example=0)
    Has_Mortgage_Loan: int = Field(..., example=0)
    Has_Gold_Card: int = Field(..., example=0)

    Complaint_Count_Last_6M: int = Field(..., example=0)
    Complaint_Count_Last_1M: int = Field(..., example=0)

    CC_Balance_M1: float = Field(..., example=5000.0)
    CC_Balance_M2: float = Field(..., example=4800.0)
    CC_Balance_M3: float = Field(..., example=4600.0)
    CC_Balance_M4: float = Field(..., example=5200.0)
    CC_Balance_M5: float = Field(..., example=5100.0)
    CC_Balance_M6: float = Field(..., example=4900.0)

    Credit_Flow_M1: float = Field(..., example=12000.0)
    Credit_Flow_M2: float = Field(..., example=11500.0)
    Credit_Flow_M3: float = Field(..., example=12500.0)
    Credit_Flow_M4: float = Field(..., example=11000.0)
    Credit_Flow_M5: float = Field(..., example=13000.0)
    Credit_Flow_M6: float = Field(..., example=12000.0)

    Debit_Flow_M1: float = Field(..., example=8000.0)
    Debit_Flow_M2: float = Field(..., example=7500.0)
    Debit_Flow_M3: float = Field(..., example=8200.0)
    Debit_Flow_M4: float = Field(..., example=7800.0)
    Debit_Flow_M5: float = Field(..., example=8500.0)
    Debit_Flow_M6: float = Field(..., example=8100.0)

    BBM_Connections_M1: int = Field(..., example=25)
    BBM_Connections_M2: int = Field(..., example=22)
    BBM_Connections_M3: int = Field(..., example=28)
    BBM_Connections_M4: int = Field(..., example=20)
    BBM_Connections_M5: int = Field(..., example=24)
    BBM_Connections_M6: int = Field(..., example=26)

    Card_Online_Count_M1: int = Field(..., example=8)
    Card_Online_Count_M2: int = Field(..., example=7)
    Card_Online_Count_M3: int = Field(..., example=9)
    Card_Online_Count_M4: int = Field(..., example=6)
    Card_Online_Count_M5: int = Field(..., example=8)
    Card_Online_Count_M6: int = Field(..., example=7)

    Card_Online_Vol_M1: float = Field(..., example=1500.0)
    Card_Online_Vol_M2: float = Field(..., example=1400.0)
    Card_Online_Vol_M3: float = Field(..., example=1600.0)
    Card_Online_Vol_M4: float = Field(..., example=1300.0)
    Card_Online_Vol_M5: float = Field(..., example=1550.0)
    Card_Online_Vol_M6: float = Field(..., example=1450.0)

    ATM_Withdrawals_Count_M1: int = Field(..., example=4)
    ATM_Withdrawals_Count_M2: int = Field(..., example=3)
    ATM_Withdrawals_Count_M3: int = Field(..., example=5)
    ATM_Withdrawals_Count_M4: int = Field(..., example=4)
    ATM_Withdrawals_Count_M5: int = Field(..., example=3)
    ATM_Withdrawals_Count_M6: int = Field(..., example=4)

    ATM_Withdrawals_Vol_M1: float = Field(..., example=2000.0)
    ATM_Withdrawals_Vol_M2: float = Field(..., example=1800.0)
    ATM_Withdrawals_Vol_M3: float = Field(..., example=2200.0)
    ATM_Withdrawals_Vol_M4: float = Field(..., example=1900.0)
    ATM_Withdrawals_Vol_M5: float = Field(..., example=2100.0)
    ATM_Withdrawals_Vol_M6: float = Field(..., example=2000.0)

    POS_Payments_Count_M1: int = Field(..., example=12)
    POS_Payments_Count_M2: int = Field(..., example=10)
    POS_Payments_Count_M3: int = Field(..., example=14)
    POS_Payments_Count_M4: int = Field(..., example=11)
    POS_Payments_Count_M5: int = Field(..., example=13)
    POS_Payments_Count_M6: int = Field(..., example=12)

    POS_Payments_Vol_M1: float = Field(..., example=3000.0)
    POS_Payments_Vol_M2: float = Field(..., example=2800.0)
    POS_Payments_Vol_M3: float = Field(..., example=3200.0)
    POS_Payments_Vol_M4: float = Field(..., example=2900.0)
    POS_Payments_Vol_M5: float = Field(..., example=3100.0)
    POS_Payments_Vol_M6: float = Field(..., example=3000.0)

    Branch_Trans_Count_M1: int = Field(..., example=2)
    Branch_Trans_Count_M2: int = Field(..., example=1)
    Branch_Trans_Count_M3: int = Field(..., example=3)
    Branch_Trans_Count_M4: int = Field(..., example=2)
    Branch_Trans_Count_M5: int = Field(..., example=1)
    Branch_Trans_Count_M6: int = Field(..., example=2)

    Branch_Trans_Vol_M1: float = Field(..., example=5000.0)
    Branch_Trans_Vol_M2: float = Field(..., example=4500.0)
    Branch_Trans_Vol_M3: float = Field(..., example=5500.0)
    Branch_Trans_Vol_M4: float = Field(..., example=4800.0)
    Branch_Trans_Vol_M5: float = Field(..., example=5200.0)
    Branch_Trans_Vol_M6: float = Field(..., example=5000.0)

    Interbank_Transfers_Count_M1: int = Field(..., example=3)
    Interbank_Transfers_Count_M2: int = Field(..., example=2)
    Interbank_Transfers_Count_M3: int = Field(..., example=4)
    Interbank_Transfers_Count_M4: int = Field(..., example=3)
    Interbank_Transfers_Count_M5: int = Field(..., example=2)
    Interbank_Transfers_Count_M6: int = Field(..., example=3)

    Balance_Trend_Ratio: float = Field(..., example=0.95)
    BBM_Connections_Drop_Ratio: float = Field(..., example=0.05)
    Card_Payments_Drop_Ratio: float = Field(..., example=0.03)
    Creditor_Flow_Drop: int = Field(..., example=0)
    Salary_Drop_Ratio: float = Field(..., example=0.02)


class PredictionResponse(BaseModel):
    client_id: Optional[str]
    prediction: int = Field(..., description="0 = Actif, 1 = Churner")
    label: str = Field(..., description="Actif ou Churner")
    churn_probability: float = Field(..., description="Probabilité de churn (0-1)")
    retention_probability: float = Field(..., description="Probabilité de rétention (0-1)")
    risk_level: str = Field(..., description="Faible / Moyen / Élevé / Critique")
    confidence: str = Field(..., description="Niveau de confiance du modèle")
    timestamp: str


class BatchRequest(BaseModel):
    clients: List[ClientData] = Field(..., min_length=1, max_length=1000)


class BatchResponse(BaseModel):
    total: int
    churners: int
    actifs: int
    churn_rate: float
    predictions: List[PredictionResponse]


# ─────────────────────────────────────────────
# Fonctions utilitaires
# ─────────────────────────────────────────────
def get_risk_level(probability: float) -> str:
    if probability < 0.25: return "Faible"
    elif probability < 0.50: return "Moyen"
    elif probability < 0.75: return "Élevé"
    else: return "Critique"


def get_confidence(probability: float) -> str:
    distance = abs(probability - 0.5)
    if distance > 0.4: return "Très élevée"
    elif distance > 0.25: return "Élevée"
    elif distance > 0.1: return "Modérée"
    else: return "Faible"


def client_to_features(client: ClientData) -> pd.DataFrame:
    data = {col: getattr(client, col) for col in FEATURE_COLUMNS}
    return pd.DataFrame([data])[FEATURE_COLUMNS]


def make_prediction(client: ClientData) -> PredictionResponse:
    try:
        df = client_to_features(client)
        prediction = int(model.predict(df)[0])
        proba = model.predict_proba(df)[0]
        churn_prob = float(proba[1])
        retention_prob = float(proba[0])

        return PredictionResponse(
            client_id=client.client_id,
            prediction=prediction,
            label="Churner" if prediction == 1 else "Actif",
            churn_probability=round(churn_prob, 4),
            retention_probability=round(retention_prob, 4),
            risk_level=get_risk_level(churn_prob),
            confidence=get_confidence(churn_prob),
            timestamp=datetime.now().isoformat(),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors de la prédiction : {str(e)}")


# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.get("/health", tags=["Monitoring"])
async def health_check():
    return {
        "status": "healthy",
        "api_version": "1.0.0",
        "model": model_name,
        "timestamp": datetime.now().isoformat(),
    }


@app.get("/model/info", tags=["Monitoring"])
async def model_info():
    try:
        params = model.get_params() if hasattr(model, "get_params") else {}
        clean_params = {k: (None if isinstance(v, float) and math.isnan(v) else v) for k, v in params.items()}

        return {
            "model_name": model_name,
            "n_features": len(FEATURE_COLUMNS),
            "target": "Attrition_Target (0=Actif, 1=Churner)",
            "hyperparameters": clean_params,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/features", tags=["Monitoring"])
async def get_features():
    return {"n_features": len(FEATURE_COLUMNS), "features": FEATURE_COLUMNS}


@app.post("/predict", response_model=PredictionResponse, tags=["Prédiction"])
async def predict_single(client: ClientData):
    return make_prediction(client)


@app.post("/predict/batch", response_model=BatchResponse, tags=["Prédiction"])
async def predict_batch(batch: BatchRequest):
    predictions = [make_prediction(client) for client in batch.clients]
    churners = sum(1 for p in predictions if p.prediction == 1)
    total = len(predictions)

    return BatchResponse(
        total=total,
        churners=churners,
        actifs=total - churners,
        churn_rate=round(churners / total, 4),
        predictions=predictions,
    )


from fastapi import Request

@app.post("/predict/batch_raw", tags=["Prédiction"])
async def predict_batch_raw(request: Request):
    """Accepte une liste de dictionnaires (JSON) pour une prédiction ultra-rapide par lot."""
    try:
        data = await request.json()
        if not data:
            raise HTTPException(status_code=400, detail="Données vides")
        
        df = pd.DataFrame(data)
        
        # Vérifier les colonnes
        missing = [c for c in FEATURE_COLUMNS if c not in df.columns]
        if missing:
            raise HTTPException(status_code=400, detail=f"Colonnes manquantes: {missing}")
            
        X = df[FEATURE_COLUMNS]
        probas = model.predict_proba(X)[:, 1]
        preds = model.predict(X)
        
        return {
            "predictions": preds.tolist(),
            "probabilities": probas.tolist()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur de prédiction batch: {str(e)}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
