"""
Script de test pour l'API FastAPI d'attrition client.
Usage : python test_api.py
Assurez-vous que l'API tourne sur http://localhost:8000 avant d'exécuter ce script.
"""

import requests
import json

BASE_URL = "http://localhost:8000"

# ─── Données de test (client à faible risque) ────────────────────────────────
CLIENT_ACTIF = {
    "client_id": "CLI_TEST_001",
    "Age": 42, "Gender": 1, "Region": 3, "Urban_Rural": 1,
    "Seniority_Months": 60, "Customer_Segment": 2,
    "Has_Salary_Domestication": 1, "Has_BBM_App": 1, "Has_Active_Card": 1,
    "Has_Savings_CEN": 0, "Has_Consumer_Loan": 0, "Has_Mortgage_Loan": 0, "Has_Gold_Card": 0,
    "Complaint_Count_Last_6M": 0, "Complaint_Count_Last_1M": 0,
    "CC_Balance_M1": 5000, "CC_Balance_M2": 4800, "CC_Balance_M3": 4600,
    "CC_Balance_M4": 5200, "CC_Balance_M5": 5100, "CC_Balance_M6": 4900,
    "Credit_Flow_M1": 12000, "Credit_Flow_M2": 11500, "Credit_Flow_M3": 12500,
    "Credit_Flow_M4": 11000, "Credit_Flow_M5": 13000, "Credit_Flow_M6": 12000,
    "Debit_Flow_M1": 8000, "Debit_Flow_M2": 7500, "Debit_Flow_M3": 8200,
    "Debit_Flow_M4": 7800, "Debit_Flow_M5": 8500, "Debit_Flow_M6": 8100,
    "BBM_Connections_M1": 25, "BBM_Connections_M2": 22, "BBM_Connections_M3": 28,
    "BBM_Connections_M4": 20, "BBM_Connections_M5": 24, "BBM_Connections_M6": 26,
    "Card_Online_Count_M1": 8, "Card_Online_Count_M2": 7, "Card_Online_Count_M3": 9,
    "Card_Online_Count_M4": 6, "Card_Online_Count_M5": 8, "Card_Online_Count_M6": 7,
    "Card_Online_Vol_M1": 1500, "Card_Online_Vol_M2": 1400, "Card_Online_Vol_M3": 1600,
    "Card_Online_Vol_M4": 1300, "Card_Online_Vol_M5": 1550, "Card_Online_Vol_M6": 1450,
    "ATM_Withdrawals_Count_M1": 4, "ATM_Withdrawals_Count_M2": 3, "ATM_Withdrawals_Count_M3": 5,
    "ATM_Withdrawals_Count_M4": 4, "ATM_Withdrawals_Count_M5": 3, "ATM_Withdrawals_Count_M6": 4,
    "ATM_Withdrawals_Vol_M1": 2000, "ATM_Withdrawals_Vol_M2": 1800, "ATM_Withdrawals_Vol_M3": 2200,
    "ATM_Withdrawals_Vol_M4": 1900, "ATM_Withdrawals_Vol_M5": 2100, "ATM_Withdrawals_Vol_M6": 2000,
    "POS_Payments_Count_M1": 12, "POS_Payments_Count_M2": 10, "POS_Payments_Count_M3": 14,
    "POS_Payments_Count_M4": 11, "POS_Payments_Count_M5": 13, "POS_Payments_Count_M6": 12,
    "POS_Payments_Vol_M1": 3000, "POS_Payments_Vol_M2": 2800, "POS_Payments_Vol_M3": 3200,
    "POS_Payments_Vol_M4": 2900, "POS_Payments_Vol_M5": 3100, "POS_Payments_Vol_M6": 3000,
    "Branch_Trans_Count_M1": 2, "Branch_Trans_Count_M2": 1, "Branch_Trans_Count_M3": 3,
    "Branch_Trans_Count_M4": 2, "Branch_Trans_Count_M5": 1, "Branch_Trans_Count_M6": 2,
    "Branch_Trans_Vol_M1": 5000, "Branch_Trans_Vol_M2": 4500, "Branch_Trans_Vol_M3": 5500,
    "Branch_Trans_Vol_M4": 4800, "Branch_Trans_Vol_M5": 5200, "Branch_Trans_Vol_M6": 5000,
    "Interbank_Transfers_Count_M1": 3, "Interbank_Transfers_Count_M2": 2,
    "Interbank_Transfers_Count_M3": 4, "Interbank_Transfers_Count_M4": 3,
    "Interbank_Transfers_Count_M5": 2, "Interbank_Transfers_Count_M6": 3,
    "Balance_Trend_Ratio": 0.95, "BBM_Connections_Drop_Ratio": 0.05,
    "Card_Payments_Drop_Ratio": 0.03, "Creditor_Flow_Drop": 0, "Salary_Drop_Ratio": 0.02,
}

# ─── Client à risque élevé ────────────────────────────────────────────────────
CLIENT_CHURNER = {**CLIENT_ACTIF,
    "client_id": "CLI_TEST_002",
    "Complaint_Count_Last_6M": 5,
    "Complaint_Count_Last_1M": 2,
    "Has_BBM_App": 0,
    "Has_Active_Card": 0,
    "BBM_Connections_M1": 2, "BBM_Connections_M2": 1, "BBM_Connections_M3": 0,
    "BBM_Connections_M4": 0, "BBM_Connections_M5": 0, "BBM_Connections_M6": 0,
    "Balance_Trend_Ratio": 0.30,
    "BBM_Connections_Drop_Ratio": 0.90,
    "Card_Payments_Drop_Ratio": 0.80,
    "Creditor_Flow_Drop": 1,
    "Salary_Drop_Ratio": 0.75,
}

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print('='*60)

def test_health():
    print_section("TEST 1 : Health Check")
    r = requests.get(f"{BASE_URL}/health")
    print(f"Status: {r.status_code}")
    print(json.dumps(r.json(), indent=2, ensure_ascii=False))

def test_model_info():
    print_section("TEST 2 : Informations Modèle")
    r = requests.get(f"{BASE_URL}/model/info")
    print(f"Status: {r.status_code}")
    data = r.json()
    print(f"  Modèle    : {data.get('model_name')}")
    print(f"  Features  : {data.get('n_features')}")
    print(f"  Cible     : {data.get('target')}")

def test_predict_actif():
    print_section("TEST 3 : Prédiction - Client Actif")
    r = requests.post(f"{BASE_URL}/predict", json=CLIENT_ACTIF)
    print(f"Status: {r.status_code}")
    data = r.json()
    print(f"  Client ID          : {data.get('client_id')}")
    print(f"  Prédiction         : {data.get('prediction')} ({data.get('label')})")
    print(f"  Proba de churn     : {data.get('churn_probability'):.1%}")
    print(f"  Proba de rétention : {data.get('retention_probability'):.1%}")
    print(f"  Niveau de risque   : {data.get('risk_level')}")
    print(f"  Confiance          : {data.get('confidence')}")

def test_predict_churner():
    print_section("TEST 4 : Prédiction - Client à Risque")
    r = requests.post(f"{BASE_URL}/predict", json=CLIENT_CHURNER)
    print(f"Status: {r.status_code}")
    data = r.json()
    print(f"  Client ID          : {data.get('client_id')}")
    print(f"  Prédiction         : {data.get('prediction')} ({data.get('label')})")
    print(f"  Proba de churn     : {data.get('churn_probability'):.1%}")
    print(f"  Proba de rétention : {data.get('retention_probability'):.1%}")
    print(f"  Niveau de risque   : {data.get('risk_level')}")
    print(f"  Confiance          : {data.get('confidence')}")

def test_batch():
    print_section("TEST 5 : Prédiction en Lot (Batch)")
    batch = {"clients": [CLIENT_ACTIF, CLIENT_CHURNER, CLIENT_ACTIF]}
    r = requests.post(f"{BASE_URL}/predict/batch", json=batch)
    print(f"Status: {r.status_code}")
    data = r.json()
    print(f"  Total clients  : {data.get('total')}")
    print(f"  Actifs         : {data.get('actifs')}")
    print(f"  Churners       : {data.get('churners')}")
    print(f"  Taux de churn  : {data.get('churn_rate'):.1%}")
    print("\n  Détail par client :")
    for p in data.get("predictions", []):
        print(f"    [{p['client_id']}] -> {p['label']} (churn: {p['churn_probability']:.1%}, risque: {p['risk_level']})")

if __name__ == "__main__":
    print("\n=== TEST DE L'API ATTRITION CLIENT - XGBOOST ===")
    print("Assurez-vous que l'API tourne sur http://localhost:8000\n")
    try:
        test_health()
        test_model_info()
        test_predict_actif()
        test_predict_churner()
        test_batch()
        print("\n[OK] Tous les tests sont passes avec succes !")
    except requests.exceptions.ConnectionError:
        print("\n[ERREUR] Impossible de se connecter a http://localhost:8000")
        print("   Lancez d'abord : python -m uvicorn main:app --reload")
